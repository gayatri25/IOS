//
//  webviewViewController.swift
//  task_surat
//
//  Created by TOPS on 11/29/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit

class webviewViewController: UIViewController {

    @IBOutlet var webview: UIWebView!
    var strarr:[Any] = []
    var sqldata:[Any] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        print(strarr)
        print(sqldata)
        let name = sqldata[0] as! String
        let shortname = sqldata[1] as! String
        print(name)
        print(shortname)
        
        
        let link = strarr[0]
        print(link)
        let url = URL(string: link as! String)
        webview.loadRequest(URLRequest.init(url: url!))

        let db = dbclass()
        let query = "select * from student1"
        let arr = db.getdata(query: query)
        print(arr)
        // Do any additional setup after loading the view.
    }

    @IBAction func btn(_ sender: Any) {
        
        let alt = UIAlertController(title: "Alert", message: nil, preferredStyle: .alert)
        let ok = UIAlertAction(title: "ok", style: .default, handler: nil)
        let save = UIAlertAction(title: "save", style: .default, handler: { action in
          
            let db = dbclass()
            let name = self.sqldata[0] as! String
            let shortname = self.sqldata[1] as! String

            
            
            let query = "insert into student1(name,shortname) values ('\(name)','\(shortname)')";
            
            let st = db.dmloperation(query: query)
            
            if st == true {
                print("record inserted successfully")
                
                let db = dbclass()
                let query = "select * from student1"
                arr = db.getdata(query: query)
                print(arr)
                
            }
                
            else {
                print("record not inserted")
            }

                      
        })
        alt
        .addAction(ok)
        alt.addAction(save)
        self.present(alt, animated: true, completion: nil)
        
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
