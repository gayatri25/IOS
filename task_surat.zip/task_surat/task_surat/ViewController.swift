//
//  ViewController.swift
//  task_surat
//
//  Created by TOPS on 11/29/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit


var arr:[Any] = []
var brr:[Any] = []
var crr:[Any] = []
var sql:[Any] = []

var a = 0

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource  {

    @IBOutlet var tbl: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tbl.estimatedRowHeight = 600
        
        tbl.rowHeight = UITableViewAutomaticDimension
        
        let url = URL(string: "http://api.kivaws.org/v1/lenders/jeremy/teams.json")
        do {
            let data = try Data(contentsOf: url!)
            
            //let data = try Data(contentsOf: url!)
            do {
                let jsondata = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                
                let teams = jsondata["teams"] as! [[String:Any]]
                
                
                for i  in teams {
                    var temp1:[String] = []
                    var temp2:[String] = []
                    var temp3:[String] = []
                    var temp4:[String] = []
                    
                    temp1.append(i["shortname"] as! String)
                    temp4.append(i["shortname"] as! String)
                    temp2.append(i["name"] as! String)
                    temp4.append(i["name"] as! String)
                    temp1.append(i["description"] as! String)
                    temp2.append(i["loan_because"] as! String)
                    temp3.append(i["website_url"] as! String)
                    arr.append(temp1)
                    
                    brr.append(temp2)
                    
                    crr.append(temp3)
                    sql.append(temp4)
                }
                
                print(sql)
                
            } catch  {
                
            }
            
            tbl.reloadData()
            
        } catch  {
            
        }
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arr.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let  cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let  temp1:[String] = arr[indexPath.section]  as! [String]
        print(temp1)
        
        cell.detailTextLabel?.text = temp1[1]
        cell.textLabel?.text = temp1[0]
        cell.accessoryType = UITableViewCellAccessoryType.detailDisclosureButton
        
        return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        a = indexPath.row
        
        
    }
    func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        
        let temp = brr[indexPath.section] as! [String]
        let loan = temp[1]
        let namee = temp[0]
        print(loan)
        print(namee)
        
        let aly = UIAlertController(title: namee, message: loan, preferredStyle: .alert)
        let  ok = UIAlertAction(title: "OK", style: .default, handler: nil)
        let  more = UIAlertAction(title: "more", style: .default, handler: { action in
            
            let f1 = self.storyboard?.instantiateViewController(withIdentifier: "1") as! webviewViewController
            
            let temp3:[String] = crr[indexPath.section] as! [String]
            print(temp3)
            let temp4:[String] = sql[indexPath.section] as! [String]
            print(temp4)
            f1.strarr = temp3
            f1.sqldata = temp4
            
            self.navigationController?.pushViewController(f1, animated: true)
            
            
        })
        
        
        aly.addAction(ok)
        aly.addAction(more)
        self.present(aly, animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

