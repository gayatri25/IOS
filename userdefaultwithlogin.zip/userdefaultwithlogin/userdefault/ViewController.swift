//
//  ViewController.swift
//  userdefault
//
//  Created by TOPS on 11/21/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var arr:[Any] = []
    
    @IBOutlet var txtpassword: UITextField!
    @IBOutlet var txtemail: UITextField!
    @IBOutlet var lbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        let dif = UserDefaults()
        let loginstatus = dif.value(forKey:"Login" ) as! String;
        
        if loginstatus == "1"
            
        {
            let page = self.storyboard?.instantiateViewController(withIdentifier: "1") as! afterlogin
            self.navigationController?.pushViewController(page, animated: true)
        }
        else
        {
            let f1 = self.storyboard?.instantiateViewController(withIdentifier: "login") as! ViewController
            self.navigationController?.pushViewController(f1, animated: true)
            
        }
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnlogin(_ sender: Any) {
        
        let test = "http://localhost/project/select_req.php"
        
        let strbody = "emp_name=\(txtemail.text!)&emp_mob=\(txtpassword.text!)"
        let url = URL(string: test)
        var request = URLRequest(url: url!)
        request.addValue(strbody, forHTTPHeaderField: "Content-Length")
        request.httpBody = strbody.data(using: String.Encoding.utf8)
        request.httpMethod = "POST"
        let sessio = URLSession.shared
        let datatask = sessio.dataTask(with: request, completionHandler: {(data1,resp,err) in
         let resp = String(data: data1!, encoding: String.Encoding.utf8)
            print(resp ?? "ok")
            DispatchQueue.main.async {
                do {
                    //let dif = UserDefaults()
                   // dif.set("1", forKey: "Login")
                
                let jsondata  = try JSONSerialization.jsonObject(with: data1!, options: []) as! [[String:Any]]
                    
                    for i in jsondata{
                        var temp:[String] = []
                        temp.append(i["id"] as! String)
                        temp.append(i["emp_name"] as! String)
                        temp.append(i["emp_add"] as! String)
                        temp.append(i["emp_mob"] as! String)
                        self.arr.append(temp)
                    }
                    print(self.arr)
                    if jsondata.count == 1 {
                        let alt = UIAlertController(title: "Alert", message: "LOGIN SUCCESFULL", preferredStyle: .alert)
                        let OK  = UIAlertAction(title: "OK", style: .default, handler: { action in
                            let dif = UserDefaults()
                            dif.set("1", forKey: "Login")
                            
                            let page = self.storyboard?.instantiateViewController(withIdentifier: "1") as! afterlogin
                            self.navigationController?.pushViewController(page, animated: true)}
                            )
                        alt.addAction(OK)
                        self.present(alt, animated: true, completion: nil)
                    }else
                    {
                        let alt = UIAlertController(title: "LOGIN", message: "Login Failed", preferredStyle: .alert);
                        
                        let ok = UIAlertAction(title: "Ok", style: .default, handler: {
                        action in
                            let dif = UserDefaults()
                            dif.set("0", forKey: "Login")
                            
                            let page = self.storyboard?.instantiateViewController(withIdentifier: "login") as! ViewController
                            self.navigationController?.pushViewController(page, animated: true)
                            
                        })
                        
                        alt.addAction(ok);
                        
                        self.present(alt, animated: true, completion: nil);
                    }
                }catch{
                    
                }
            }
        
        })
        datatask.resume()
        
        
        
        
        
        
        
        
    }
    
    @IBAction func btnsignup(_ sender: Any) {
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

