//
//  ViewController.swift
//  sqlite3
//
//  Created by TOPS on 10/28/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    var finalarr:[Any] = []
    
    
    @IBOutlet var btn: UIButton!
    @IBOutlet var tbl: UITableView!
    @IBOutlet var name: UITextField!
    @IBOutlet var txtid: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        bind()
        // Do any additional setup after loading the view, typically from a nib.
    }
    func bind()    {
        let db = dbclass()
        let arr = db.getdata(query: "select * from tblemp")
        print(arr)
        finalarr = arr
        
        
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return finalarr.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let temp = finalarr[indexPath.section] as! [String]
        cell.textLabel?.text    = temp[indexPath.row]
        return cell
        
        
    }
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        let temp = finalarr[indexPath.section] as! [String]

        let empid = temp[0]
        let query = "delete from tblemp where id='\(empid)'"
        let db = dbclass()
        let st = db.dmlopearion(query: query)
        if st == true {
            finalarr.remove(at: indexPath.section)
            tableView.reloadData()
        }
        
        
        
        
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let temp = finalarr[indexPath.section] as! [String]
        txtid.text = temp[0]
        name.text = temp[1]
        btn.setTitle("update", for: .normal)
        
    }
    @IBAction func dlete(_ sender: Any) {
        let db = dbclass()
        let query = "delete from tblemp where id='\(txtid.text!)'"
        let st = db.dmlopearion(query: query)
        if st == true {
            print("yes")
            bind()
            tbl.reloadData()
            
        }
        else{
            print("no")
        }
        
        
        
        
        
    }
   
    @IBAction func btn(_ sender: Any) {
        
        if btn.titleLabel?.text == "insert" {
            let db = dbclass()
            let query = "insert into tblemp(id,name) values('\(txtid.text!)','\(name.text!)')"
            let st = db.dmlopearion(query: query)
            if st == true {
                print("yes")
                bind()
                tbl.reloadData()
            txtid.becomeFirstResponder()
            }
            else
            {
                print("no")
            }
            
            
            
        }
        else{
            let db = dbclass()
            let query = "update tblemp set name = '\(name.text!)' where id = '\(txtid.text!)'"
            
            let st = db.dmlopearion(query: query)
            if st == true {
                print("yes")
            
                txtid.text = ""
                name.text = ""
                
                bind()
                tbl.reloadData()
                txtid.becomeFirstResponder()
            btn.setTitle("insert", for: .normal)
                tbl.reloadData()
            
            }
                
                
            else
            {
                print("no")
            }

        }
        
        
    
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

