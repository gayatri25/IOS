//
//  dbclass.swift
//  sqlite3
//
//  Created by TOPS on 10/28/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit

class dbclass: NSObject {

    func dmlopearion(query:String) -> Bool {
        var  status:Bool = true
       
        
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path1 = path[0]
        
        let fullpath = path1.appending("/sub.db")
        print(fullpath)
        var qp: OpaquePointer? = nil
        
        if sqlite3_open(fullpath, &qp) == SQLITE_OK {
            var stmt: OpaquePointer? = nil
            
            if sqlite3_prepare_v2(qp, query, -1, &stmt, nil) == SQLITE_OK {
                sqlite3_step(stmt)
                status  = true
            }
            
            sqlite3_finalize(stmt)
            sqlite3_close(qp)
        }
        return status
    }
    
    func getdata(query: String) -> [Any] {
        //var  status:Bool = true
        var final:[Any] = []
        
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path1 = path[0]
        let fullpath = path1.appending("/sub.db")
        print(fullpath)
        var qp: OpaquePointer? = nil
        if sqlite3_open(fullpath, &qp) == SQLITE_OK {
            var stmt: OpaquePointer? = nil
            
            if sqlite3_prepare_v2(qp, query, -1, &stmt, nil) == SQLITE_OK {
                while sqlite3_step(stmt) == SQLITE_ROW {
                    var temp:[String] = []
                    let id = String(cString: sqlite3_column_text(stmt, 0))
                    let name = String(cString: sqlite3_column_text(stmt, 1))
                    temp.append(id)
                    temp.append(name)
                    final.append(temp)
                    
                }
            }
            
            sqlite3_finalize(stmt)
            sqlite3_close(qp)
        }
        return final
        
        
    }
    
    
    
    
}
