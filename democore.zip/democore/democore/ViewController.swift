//
//  ViewController.swift
//  democore
//
//  Created by TOPS on 11/8/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    
    let arr:[String] = []
    
    var brr:[String] = []
    
    @IBOutlet var tbl: UITableView!
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    @IBOutlet var txt2: UITextField!
    
    @IBOutlet var txt1: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btninsert(_ sender: Any) {
        let newcontxt = NSEntityDescription.insertNewObject(forEntityName: "User", into: context)
        newcontxt.setValue("\(txt1.text!)", forKey: "username")
        newcontxt.setValue("\(txt2.text!)", forKey: "password")
        print(newcontxt )
        do {
            try  context.save()
        } catch  {
            
        }
        
    }
    
    @IBAction func sese(_ sender: Any) {
        
        
        let entitydes = NSEntityDescription.entity(forEntityName: "User", in: context)
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "User")
        request.entity = entitydes
        let pred = NSPredicate(format: "(username =%@)", txt1.text!)
        request.predicate = pred
        do {
            
            let result = try context.fetch(request)
            print(result)
            if result.count > 0 {
                let manage = result[0] as! NSManagedObject
                
               
                let str1 = manage.value(forKey: "username") as? String
                let str2 = manage.value(forKey: "password") as? String
                brr.append(str1!)
                brr.append(str2!)
            
                txt1.text = manage.value(forKey: "username") as? String
                txt2.text = manage.value(forKey: "password") as? String
            }            else
            {
                print("not found")
            }
        } catch  {
            
        }
        tbl.reloadData()
       
        
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return brr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = brr[indexPath.row]
        return cell
    }
    @IBAction func upd(_ sender: Any) {
        
        let entitidec = NSEntityDescription.entity(forEntityName: "User", in: context)
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "User")
        request.entity = entitidec
        let pred = NSPredicate(format: "username =%@", txt1.text!)
        request.predicate = pred
        do {
            let result = try context.fetch(request)
            print(result)
            
            if result.count > 0 {
                let manage = result[0] as! NSManagedObject
                
                manage.setValue(txt1.text!, forKey: "username")
                manage.setValue(txt2.text!, forKey: "password")
                
                 try context.save()
                
            }
            else{
                print("not found")
            }

        } catch  {
            
        }
        tbl.reloadData()
        
        
        
        
        
    }
    @IBAction func dell(_ sender: Any) {
        
        let entitydec = NSEntityDescription.entity(forEntityName: "User", in: context)
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "User")
        request.entity = entitydec
        let pred = NSPredicate(format: "username =%@", txt1.text!)
        request.predicate = pred
        do {
            let result = try context.fetch(request)

            if result.count > 0 {
                
                let manage = result[0] as! NSManagedObject
             context.delete(manage)
                try context.save()
                
            }
            else{
                print("not found")
            }
        } catch  {
            
        }
        
        
        
        
        
        
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

