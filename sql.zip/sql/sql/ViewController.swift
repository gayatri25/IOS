//
//  ViewController.swift
//  sql
//
//  Created by TOPS on 11/14/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UINavigationControllerDelegate,UIImagePickerControllerDelegate {

    var picker = UIImagePickerController()
    
    var arr:[Any] = []
    var style = ToastStyle()
    
    @IBOutlet var txtmob: UITextField!
    @IBOutlet var txtadd: UITextField!
    @IBOutlet var txtcity: UITextField!
    @IBOutlet var txtname: UITextField!
    @IBOutlet var txtid: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        img.clipsToBounds = true
        img.layer.cornerRadius = img.frame.size.width/2
        
        tap()
        
        
        let db = dbclass()
        let query = "select * from student"
        let arr = db.getdata(query: query)
        print(arr)
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBOutlet var img: UIImageView!

    func tap()  {
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handle))
        tap.numberOfTapsRequired = 1
        img.isUserInteractionEnabled = true
        img.addGestureRecognizer(tap)
        
    }
    func handle(sender: UITapGestureRecognizer) {
        picker.sourceType = .photoLibrary
        picker.delegate = self
        self.present(picker, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        img.image = info[UIImagePickerControllerOriginalImage] as? UIImage
        self.dismiss(animated: true, completion: nil)
        
    }
    func saveImageDocumentDirectory(imgname:String,imagedata:UIImage){
        
        let fileManager = FileManager.default
        let paths = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent(imgname)
        print(paths);
        
        let image = imagedata;
        
        print(paths)
        let imageData = UIImageJPEGRepresentation(image, 0.5)
        fileManager.createFile(atPath: paths as String, contents: imageData, attributes: nil)
        
    }

    
    @IBAction func submit(_ sender: Any) {
        
        
        let db = dbclass()
        let imgname = txtname.text!+".jpg"
        
        let query = "insert into student(id,name,address,city,mobile,img) values('\(txtid.text!)','\(txtname.text!)','\(txtadd.text!)','\(txtcity.text!)','\(txtmob.text!)','\(imgname)')";
        
        
        self .saveImageDocumentDirectory(imgname: imgname, imagedata: img.image!)
        
        
        let st = db.dmloperation(query: query)
        
        txtid.text = "";
        txtname.text = "";
        txtcity.text = "";
        txtadd.text = "";
        txtmob.text = "";
        
        
        
        if st == true {
            print("record inserted successfully")
            
            //   let alert = UIAlertController(title: "success", message: "record inserted successfully", preferredStyle: .alert)
            // alert.self
            let db = dbclass()
            let query = "select * from student"
            arr = db.getdata(query: query)
            print(arr)
            
            let f1 = storyboard?.instantiateViewController(withIdentifier: "profile") as! profilelistViewController
            f1.b = 1
            self.navigationController?.pushViewController(f1, animated: true)
            
        
            
            
        }
            
        else {
            print("record not inserted")
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

