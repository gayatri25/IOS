//
//  viewprofile.swift
//  sql
//
//  Created by TOPS on 11/15/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit

class viewprofile: UIViewController {

    @IBOutlet var txtmob: UITextField!
   
    @IBOutlet var txtadd: UITextField!
    @IBOutlet var txtcity: UITextField!
    @IBOutlet var txtname: UITextField!
    
    @IBOutlet var img: UIImageView!
    
    var brr = ""
    
    var data:[String] = []
    var arr :[Any] = []
    
    
    var style = ToastStyle()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        img.layer.cornerRadius = img.frame.size.width/2;
        img.clipsToBounds = true
        

        getdata()
        // Do any additional setup after loading the view.
    }
    
    func getdata()  {
        let db = dbclass()
        let query = "select * from student where id='\(brr)'"
        arr = db.getdata(query: query)
        print(arr)
        let brr1 = arr[0] as! [String]
        print(brr1)
        
        txtname.text = brr1[1]
        txtadd.text = brr1[2]
        txtcity.text = brr1[3]
        txtmob.text = brr1[4]
        let imgname = brr1[5]
        img.image = getImage(imgname: imgname)
        img.layer.cornerRadius = img.frame.size.width/2
        img.clipsToBounds = true
       
        txtname.isUserInteractionEnabled = false
        txtadd.isUserInteractionEnabled = false
        txtmob.isUserInteractionEnabled = false
        txtcity.isUserInteractionEnabled = false
        

        
    }
    
    
    func getImage(imgname:String)->UIImage {
        let fileManager = FileManager.default
        let imagePAth = (self.getDirectoryPath() as NSString).appendingPathComponent(imgname)
        if fileManager.fileExists(atPath: imagePAth){
            return UIImage(contentsOfFile: imagePAth)!
        }else{
            
            return UIImage(named: "4.png")!;
        }
    }
    
    func getDirectoryPath() -> String {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentsDirectory = paths[0]
        return documentsDirectory
    }
    

    @IBAction func btnaction(_ sender: Any) {
    
        txtname.isUserInteractionEnabled = true
        txtadd.isUserInteractionEnabled = true
        txtmob.isUserInteractionEnabled = true
        txtcity.isUserInteractionEnabled = true
        
        
    
    
    
    }
    
    
    @IBAction func btndone(_ sender: Any) {
        
        txtname.isUserInteractionEnabled = false
        txtadd.isUserInteractionEnabled = false
        txtmob.isUserInteractionEnabled = false
        txtcity.isUserInteractionEnabled = false
        
        let brr1 = arr[0] as! [String]
        
        
        print(brr1)
        let db = dbclass()
        let query = String(format: "update student set name = '%@', address = '%@', city = '%@', mobile = '%@' where id = '\(brr1[0])'", txtname.text!,txtadd.text!,txtcity.text!,txtmob.text!)
    
        
        let st = db.dmloperation(query: query)
        //  tbl.reloadData()
        if st == true {
            print("record updated successfully")
            //   let alert = UIAlertController(title: "success", message: "record inserted successfully", preferredStyle: .alert)
            // alert.self
            let db = dbclass()
            let query = "select * from student"
            arr = db.getdata(query: query)
            let  brr1 =  arr[0] as! [String];
            
            txtname.text = brr1[1]
            txtadd.text = brr1[2]
            txtcity.text = brr1[3]
            txtmob.text = brr1[4]
            
            style.messageColor = .white
            self.view.makeToast("Data Updated SuccessFully", duration: 1.5, position: .center, style: style)
            
        }
        else {
            print("record not updated")
            //  let alert = UIAlertController(title: "unsuccess", message: "record not inserted", preferredStyle: .alert)
            //  alert.self
            
        }
        
        
    }
    

        
        
        
    
    
    
    
    
        override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
