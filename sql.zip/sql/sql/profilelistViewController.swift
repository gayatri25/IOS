//
//  profilelistViewController.swift
//  sql
//
//  Created by TOPS on 11/15/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit

class profilelistViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet var tbl: UITableView!
    
    var arr:[Any] = []
    var style = ToastStyle()
    var b = Int()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

       // navigationController?.navigationBar.isHidden = true
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        
        if b == 1
            
        {
            style.messageColor = .white
            self.view.makeToast("Data Submitted SuccessFully", duration: 1.5, position: .center, style: style)
        }
        
        
        let db = dbclass()
        let query = "select * from student"
        arr = db.getdata(query: query)
        
        print(arr)
        tbl.reloadData()
        
        
    }

    @IBAction func adde(_ sender: Any) {
        
        let add = self.storyboard?.instantiateViewController(withIdentifier: "2") as! ViewController
        self.navigationController?.pushViewController(add, animated: true)
        
    }
    
    
    func getImage(imgname:String)->UIImage
    {
        let fileManager = FileManager.default
        
        let imagePAth = (self.getDirectoryPath() as NSString).appendingPathComponent(imgname)
        
        if fileManager.fileExists(atPath: imagePAth)
        {
            return UIImage(contentsOfFile: imagePAth)!
        }
        else
        {
            return UIImage(named: "4.png")!;
        }
    }
    
    func getDirectoryPath() -> String {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        
        let documentsDirectory = paths[0]
        
        return documentsDirectory
    }
    

    func numberOfSections(in tableView: UITableView) -> Int {
        return  arr.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! custcell
        var trmp = arr[indexPath.section] as! [String]
        
        cell.lbl1.text = trmp[1]
        cell.lbl2.text = trmp[4]
        
        let imgname = trmp[5]
       cell.img.image = getImage(imgname: imgname)
       cell.img.layer.cornerRadius = cell.img.frame.size.width/2;
        cell.img.clipsToBounds = true
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let displayprofile = storyboard?.instantiateViewController(withIdentifier: "3") as! viewprofile
        var trmp = arr[indexPath.section] as! [String]
        
        displayprofile.brr = trmp[0]
        self.navigationController?.pushViewController(displayprofile, animated: true)

        
        
        
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
            
            var trmp = self.arr[indexPath.section] as! [String]
            let index = trmp[0]
            
            let db = dbclass()
            let delete = "delete from student where id = '\(index)'"
            
            let st = db.dmloperation(query: delete)
            
            if st == true {
                print("record deleted successfully")
                
                let db = dbclass()
                let query = "select * from student"
                arr = db.getdata(query: query)
                tbl.reloadData()
                style.messageColor = .white
                self.view.makeToast("Data Deleted SuccessFully", duration: 1.5, position: .center, style: style)
            }
            else {
                print("record not deleted")
                //  let alert = UIAlertController(title: "unsuccess", message: "record not inserted", preferredStyle: .alert)
                //  alert.self
                
            }
            
            
            
            
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

class custcell: UITableViewCell {
    

    @IBOutlet var lbl2: UILabel!
    @IBOutlet var img: UIImageView!

    @IBOutlet var lbl1: UILabel!



}
